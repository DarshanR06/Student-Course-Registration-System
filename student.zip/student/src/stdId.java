/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ujju
 */
public class stdId {
    /*plan is to get the id of the student from the login when he signs in using the email.
    when he signs in through the mail get his id and store it in this class.
    then use this value in other places to do the function.
    */
    static int stdid;
    public static void Id(int id){
        stdid = id;
    }
}
